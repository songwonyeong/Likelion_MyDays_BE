package com.mydays.backend.domain;

public enum AuthProvider {
    LOCAL, KAKAO
}
